"""Audited classic reference preview and integer-center placement."""

import io
from typing import Any

from ro_sprite_forge.formats.errors import require


def png_bytes(image: Any) -> bytes:
    """Return deterministic PNG binary bytes for PIL Image."""
    out = io.BytesIO()
    image.save(out, format="PNG", optimize=False, compress_level=9)
    return out.getvalue()


def only_clip(motion: dict[str, Any]) -> dict[str, Any]:
    """Extract single visible clip from motion, validating reference constraint."""
    clips = [c for c in motion["clips"] if c["sprite"] >= 0]
    require(len(clips) == 1, "reference requires exactly one visible clip")
    return clips[0]


def place(
    canvas: Any,
    image: Any,
    clip: dict[str, Any],
    shift: tuple[int, int] = (0, 0),
    origin: tuple[int, int] = (128, 192),
) -> None:
    """Place transformed image onto canvas at origin with clip offsets."""
    require(
        clip["scale_x"] == clip["scale_y"] == 1
        and clip["angle"] == 0
        and clip["color"] == 0xFFFFFFFF,
        "unsupported reference transform",
    )
    from PIL import Image

    if clip["mirror"]:
        image = image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    x = origin[0] + clip["x"] + shift[0] - (image.width - 1) // 2
    y = origin[1] + clip["y"] + shift[1] - (image.height - 1) // 2
    require(
        x >= 0
        and y >= 0
        and x + image.width <= canvas.width
        and y + image.height <= canvas.height,
        "reference canvas clipping",
    )
    canvas.alpha_composite(image, (x, y))


def actor_preview(body: Any, head: Any, bm: dict[str, Any], hm: dict[str, Any]) -> Any:
    """Composite single-clip body and head onto standard 256x256 canvas."""
    from PIL import Image

    image = Image.new("RGBA", (256, 256))
    place(image, body, only_clip(bm))
    ba, ha = bm["anchors"][0], hm["anchors"][0]
    place(image, head, only_clip(hm), (ba["x"] - ha["x"], ba["y"] - ha["y"]))
    return image
