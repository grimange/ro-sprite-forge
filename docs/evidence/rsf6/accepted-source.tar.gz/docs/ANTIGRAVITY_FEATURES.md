# Antigravity CLI features used in this kit

| Feature | Actual repository configuration | Operator use |
|---|---|---|
| Always-on workspace rules | `GEMINI.md` | Loaded by Antigravity for this workspace |
| Conditional domain rules | `.agents/rules/*.md` with `trigger: model_decision` | Loaded for relevant topics |
| Reusable skills | `.agents/skills/agy-forge-*/SKILL.md` | CLI slash commands such as `/agy-forge-m0-kickoff` |
| Reviewer/investigator custom agents | `.agents/agents/*.md` | `/agents`, delegation or separate session |
| Remote Kaneo MCP | `.agents/mcp_config.json` using `serverUrl` | `/mcp` checks/auth; live tools depend on server |
| Task prompts/checklists | `docs/templates/` and `docs/workflows/` | Paste or reference; not magic executable workflows |
| Session modes | Not forced by repository | `agy --mode=plan` or default; inspect `/config` |
| Settings / permissions | Kept user-local, not overwritten | `/config`, `/permissions`, avoid global auto-approval |

**No legacy `.agent/workflows/` slash workflows.** Google announced its old IDE
workflows would stop working on 2026-10-19, directing users to agent skills; hence
repeatable engineering procedures here are real `SKILL.md` bundles.

**No global settings.json included.** Per-user Antigravity defaults differ by version
and account; avoid silently changing personal permission or model choices. Suggested
starting posture: `agy` in default execution mode; keep permission prompts for
sensitive actions. To plan safely: `agy --mode=plan`; to see MCP status: `/mcp`;
to inspect custom agents: `/agents`. Don't disable certificate validation for Kaneo.

**Read-only reviewer caveat:** An agent instruction or restricted tool list is not an
OS-enforced protection. `run_command` can mutate files; use no-write command policy,
human approvals, or an isolated read-only filesystem for strict QA.

**MCP caveat:** The bundled URL definition is schema-validated only; no claim the
private LAN server, OAuth authentication, trust chain or exact tool names are live.

Docs verified for kit design (check for product updates before changing config):
- https://antigravity.google/docs/rules/
- https://antigravity.google/docs/skills/
- https://antigravity.google/docs/subagents/
- https://antigravity.google/docs/mcp/
- https://antigravity.google/docs/cli/modes/
- https://antigravity.google/docs/cli/reference/
- https://antigravity.google/docs/ide/workflows/
