import hashlib
"""M0 CLI contracts and filesystem preflight; core owns operation semantics."""

import argparse
import json
import stat
import sys
from pathlib import Path
from typing import Sequence

from ro_sprite_forge import __version__
from ro_sprite_forge.core.errors import ErrorCode, ForgeError
from ro_sprite_forge.core.operations import Operation, Request, execute
from ro_sprite_forge.core.preservation import roundtrip_pair
from ro_sprite_forge.core.canonical import canonical_bytes
from ro_sprite_forge.core.inventory import inventory
from ro_sprite_forge.core.profiles import get_profile
from ro_sprite_forge.core.requirements import requirements
from ro_sprite_forge.report_io import publish, publish_resources, read_bytes, read_json


class Parser(argparse.ArgumentParser):
    def __init__(self, *args, **kwargs):
        kwargs["allow_abbrev"] = False
        super().__init__(*args, **kwargs)

    def error(self, message: str) -> None:
        raise ForgeError(ErrorCode.INVALID_ARGUMENT, message)


def build_parser() -> Parser:
    parser = Parser(
        prog="ro-sprite-forge",
        description="Local resource inventory and bounded requirements. No artwork or native verification.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)
    for operation, purpose in (
        (Operation.INSPECT, "Inventory supported ACT 2.4 / SPR 2.1 resources as canonical JSON."),
        (Operation.PLAN, "Calculate bounded target requirements; unresolved declarations stay provisional."),
        (Operation.VERIFY, "Verify ACT/SPR structure and Python semantic roundtrip; no Rust/native claim."),
        (Operation.ROUNDTRIP, "Preserve unchanged ACT/SPR resources or explicitly serialize ACT."),
    ):
        sub = commands.add_parser(operation.value, help=purpose, description=purpose)
        if operation in (Operation.INSPECT, Operation.ROUNDTRIP):
            sub.add_argument("--act", required=True, help="Existing regular ACT input file.")
            sub.add_argument("--spr", required=True, help="Existing regular SPR input file.")
        if operation == Operation.INSPECT:
            sub.add_argument("--json", required=True, dest="output", help="New canonical inventory JSON path; parent must exist.")
            sub.add_argument("--actor", default="unspecified", help="Stable operator-supplied actor namespace, independent of filenames.")
            sub.add_argument("--part", default="body", help="Stable resource part namespace (body/head remain separate).")
            sub.add_argument("--runtime-profile", default="unverified", choices=("player", "npc", "monster", "unverified"), help="Frozen source-reviewed mapping, default unknown; never native proof.")
        elif operation == Operation.PLAN:
            for flag in ("inventory", "profile", "target"):
                sub.add_argument(f"--{flag}", required=True, help=f"Existing versioned {flag} JSON input; profile must match frozen record.")
            sub.add_argument("--output", required=True, help="New canonical requirements JSON path; parent must exist.")
        elif operation == Operation.VERIFY:
            sub.add_argument("--project", help="Legacy project verification (not yet implemented).")
            sub.add_argument("--act", help="Existing ACT 2.4 input.")
            sub.add_argument("--spr", help="Existing SPR 2.1 input.")
            sub.add_argument("--scope", choices=("full", "declared"), help="Explicit full-profile or declared-target scope.")
        else:
            sub.add_argument("--output-act", required=True, help="New ACT path; parent must exist.")
            sub.add_argument("--output-spr", required=True, help="New SPR path; parent must exist.")
            sub.add_argument("--mode", choices=("preserve", "act-semantic"), default="preserve", help="SPR always retains original bytes; conversion unsupported.")
    resolve = commands.add_parser('resolve', help='Resolve Target/v2 ordered topology without artwork.')
    for name in ('actor', 'profile', 'target'):
        resolve.add_argument('--' + name, required=True, help='Existing versioned contract JSON.')
    resolve.add_argument('--inventory', action='append', default=[], help='Explicit immutable inventory reference; repeat for resource parts.')
    resolve.add_argument('--output', required=True, help='New canonical requirements JSON path.')
    resolve.add_argument('--work-order', action='store_true', help='Also print the per-occurrence checklist.')
    ledger = commands.add_parser('ledger', help='Validate and resolve explicit artwork assignments; no image processing.')
    for name in ('requirements', 'ledger', 'output'):
        ledger.add_argument('--' + name, required=True)
    ledger.add_argument('--source', action='append', default=[], metavar='ID=PATH', help='Content bytes to verify; paths stay outside canonical reports.')
    ledger.add_argument('--missing-source', action='append', default=[], metavar='ID', help='Explicitly observed unavailable source.')
    impact = commands.add_parser('ledger-impact', help='Compare resolved ledger reports and dependency impact.')
    for name in ('before', 'after', 'output'):
        impact.add_argument('--' + name, required=True)
    impact.add_argument('--requirements', help='Current resolved requirements for orphan detection.')
    coverage = commands.add_parser('coverage', help='Evaluate target requirements coverage and export missing-art work orders.')
    coverage.add_argument('--requirements', required=True, help='Existing resolved requirements JSON.')
    coverage.add_argument('--ledger', help='Existing assignment ledger JSON (declaration or resolved report). Optional.')
    coverage.add_argument('--source', action='append', default=[], metavar='ID=PATH', help='Content bytes to verify; repeat for sources.')
    coverage.add_argument('--missing-source', action='append', default=[], metavar='ID', help='Explicitly observed unavailable source.')
    coverage.add_argument('--target', help='Optional target contract JSON.')
    coverage.add_argument('--output', help='New canonical coverage report JSON path.')
    coverage.add_argument('--work-order', action='store_true', help='Print human-readable missing-art work order to stdout.')
    coverage.add_argument('--work-order-output', help='New human-readable work order text output path.')
    coverage.add_argument('--filter', choices=('all', 'unresolved', 'supply_artwork', 'restore_or_locate_source', 'correct_invalid_source_or_assignment', 'resolve_requirements', 'verify_source_content', 'verify_transformation', 'review_artwork', 'review_stale', 'resolve_runtime_support'), default='unresolved', help='Filter displayed work order items.')
    missing = commands.add_parser('missing', help='Export human-readable missing-art work order.')
    missing.add_argument('--requirements', required=True, help='Existing resolved requirements JSON.')
    missing.add_argument('--ledger', help='Existing assignment ledger JSON. Optional.')
    missing.add_argument('--source', action='append', default=[], metavar='ID=PATH', help='Content bytes to verify.')
    missing.add_argument('--missing-source', action='append', default=[], metavar='ID', help='Explicitly observed unavailable source.')
    missing.add_argument('--target', help='Optional target contract JSON.')
    missing.add_argument('--output', help='New work order text output path; defaults to stdout.')
    missing.add_argument('--format', choices=('text', 'json'), default='text', help='Output format (text work order or canonical json).')
    missing.add_argument('--filter', choices=('all', 'unresolved', 'supply_artwork', 'restore_or_locate_source', 'correct_invalid_source_or_assignment', 'resolve_requirements', 'verify_source_content', 'verify_transformation', 'review_artwork', 'review_stale', 'resolve_runtime_support'), default='unresolved', help='Filter displayed work order items.')
    prev = commands.add_parser('preview', help='Render order-preserving multilayer preview frame.')
    prev.add_argument('--act', required=True, help='Existing regular ACT input file.')
    prev.add_argument('--spr', required=True, help='Existing regular SPR input file.')
    prev.add_argument('--action', type=int, default=0, help='Action/view slot index; default 0.')
    prev.add_argument('--frame', type=int, default=0, help='Frame/motion index within slot; default 0.')
    prev.add_argument('--head-act', help='Optional child/head ACT input for multipart actors.')
    prev.add_argument('--head-spr', help='Optional child/head SPR input for multipart actors.')
    prev.add_argument('--head-frame', type=int, help='Optional head frame index.')
    prev.add_argument('--origin', help='Canvas origin as X,Y; default 128,192.')
    prev.add_argument('--canvas-size', help='Canvas dimensions as W,H; default 256,256.')
    prev.add_argument('--auto-fit', action='store_true', help='Dynamically size canvas to contain all layers.')
    prev.add_argument('--output', help='Output PNG file path.')
    prev.add_argument('--json', help='Output canonical preview report JSON path.')
    prev.add_argument('--stdout-json', action='store_true', help='Print canonical report JSON to stdout.')
    animation = commands.add_parser('animation', help='Inspect raw ACT frames, pinned timing and compositor bounds; no approval.')
    for name in ('act', 'spr'):
        animation.add_argument('--' + name, required=True)
    animation.add_argument('--category', choices=('player', 'npc', 'monster', 'unverified'), default='unverified')
    select = animation.add_mutually_exclusive_group()
    select.add_argument('--action', help='Verified semantic action from the frozen category profile.')
    select.add_argument('--slot', type=int, help='Exact numeric ACT action/view slot; no modulo fallback.')
    animation.add_argument('--view', type=int, default=0)
    animation.add_argument('--direction', type=int)
    animation.add_argument('--camera-direction', type=int, default=0)
    animation.add_argument('--frame', type=int, default=0)
    movement = animation.add_mutually_exclusive_group()
    movement.add_argument('--step', type=int)
    movement.add_argument('--time-ms', type=int)
    animation.add_argument('--loop', action='store_true', help='Explicit manual-step wrap; runtime playback uses profile loop rules.')
    animation.add_argument('--speed', type=float, default=1.0, help='Explicit timed-preview speed multiplier.')
    animation.add_argument('--movement-speed', type=int, help='Required native Walk context.')
    animation.add_argument('--duration-ms', type=int, help='Required native Attack/Hurt context.')
    animation.add_argument('--diagnostic-frame-ms', type=float, help='Explicit diagnostic timing override; never native timing proof.')
    animation.add_argument('--head-act')
    animation.add_argument('--head-spr')
    animation.add_argument('--origin', default='128,192')
    animation.add_argument('--canvas-size', default='256,256')
    animation.add_argument('--auto-fit', action='store_true')
    animation.add_argument('--json', help='New canonical inspection report path; defaults to stdout.')
    animation.add_argument('--output', help='Optional new preview PNG path, published with the report.')
    return parser


def _path(value: str) -> Path:
    if not value or "\x00" in value:
        raise ForgeError(ErrorCode.INVALID_ARGUMENT, "Paths must be nonempty and contain no NUL.")
    return Path(value)


def _input(value: str, *, directory: bool = False) -> None:
    path = _path(value)
    try:
        mode = path.stat().st_mode
    except FileNotFoundError as exc:
        raise ForgeError(ErrorCode.INPUT_NOT_FOUND, "Input path does not exist.", path=value) from exc
    except OSError as exc:
        raise ForgeError(ErrorCode.IO_ERROR, "Cannot inspect input path.", path=value) from exc
    valid = stat.S_ISDIR(mode) if directory else stat.S_ISREG(mode)
    if not valid:
        raise ForgeError(ErrorCode.INVALID_INPUT, "Expected a directory." if directory else "Expected a regular file.", path=value)


def _output(value: str) -> None:
    path = _path(value)
    # lstat rejects even dangling output symlinks; never create, truncate or probe-write.
    try:
        path.lstat()
    except FileNotFoundError:
        pass
    except OSError as exc:
        raise ForgeError(ErrorCode.IO_ERROR, "Cannot inspect output path.", path=value) from exc
    else:
        raise ForgeError(ErrorCode.INVALID_OUTPUT, "Output already exists; overwriting is forbidden.", path=value)
    try:
        if not path.parent.is_dir():
            raise ForgeError(ErrorCode.INVALID_OUTPUT, "Output parent must be an existing directory.", path=value)
    except OSError as exc:
        raise ForgeError(ErrorCode.IO_ERROR, "Cannot inspect output parent.", path=value) from exc


def _publish_png(path: str, data: bytes) -> None:
    target = _path(path)
    temporary = None
    try:
        import os, tempfile
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix=".rsf-png-", delete=False) as stream:
            temporary = stream.name
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, target)
    except FileExistsError as exc:
        raise ForgeError(ErrorCode.INVALID_OUTPUT, "Output already exists; overwriting is forbidden.", path=path) from exc
    except OSError as exc:
        raise ForgeError(ErrorCode.IO_ERROR, "Cannot publish PNG output.", path=path) from exc
    finally:
        if temporary is not None:
            try:
                import os
                os.unlink(temporary)
            except OSError:
                pass


def _publish_text(path: str, text: str) -> None:
    data = text.encode("utf-8")
    target = _path(path)
    temporary = None
    try:
        import os, tempfile
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix=".rsf-text-", delete=False) as stream:
            temporary = stream.name
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, target)
    except FileExistsError as exc:
        raise ForgeError(ErrorCode.INVALID_OUTPUT, "Output already exists; overwriting is forbidden.", path=path) from exc
    except OSError as exc:
        raise ForgeError(ErrorCode.IO_ERROR, "Cannot publish text output.", path=path) from exc
    finally:
        if temporary is not None:
            try:
                import os
                os.unlink(temporary)
            except OSError:
                pass


def _request(args: argparse.Namespace) -> Request:
    operation = Operation(args.command)
    input_names = {
        Operation.INSPECT: ("act", "spr"),
        Operation.PLAN: ("inventory", "profile", "target"),
        Operation.VERIFY: ("project",),
        Operation.ROUNDTRIP: ("act", "spr"),
    }[operation]
    output_names = {
        Operation.INSPECT: ("output",), Operation.PLAN: ("output",),
        Operation.VERIFY: (), Operation.ROUNDTRIP: ("output_act", "output_spr"),
    }[operation]
    if operation == Operation.VERIFY:
        if args.project:
            if args.act or args.spr or not args.scope:
                raise ForgeError(ErrorCode.INVALID_ARGUMENT, "Legacy project verification requires --scope and no resource inputs.")
        else:
            if not args.act or not args.spr or args.scope:
                raise ForgeError(ErrorCode.INVALID_ARGUMENT, "Resource verification requires --act and --spr without --scope.")
            input_names = ("act", "spr")
    inputs = tuple((name, getattr(args, name)) for name in input_names)
    outputs = tuple((name, getattr(args, name)) for name in output_names)
    for name, value in inputs:
        _input(value, directory=name == "project")
    for _, value in outputs:
        _output(value)
    if len({str(_path(value).resolve()) for _, value in outputs}) != len(outputs):
        raise ForgeError(ErrorCode.INVALID_OUTPUT, "Output paths must be distinct.")
    return Request(operation, inputs, outputs, getattr(args, "scope", None))


def main(argv: Sequence[str] | None = None) -> int:
    """Render expected errors on stderr; help/version use argparse's zero exit."""
    try:
        args = build_parser().parse_args(argv)
        if args.command == 'animation':
            from ro_sprite_forge.core.animation import AnimationInspector
            from ro_sprite_forge.core.canonical import check
            for value in (args.act, args.spr, args.head_act, args.head_spr):
                if value:
                    _input(value)
            for value in (args.json, args.output):
                if value:
                    _output(value)
            if args.time_ms is None:
                check(args.speed == 1.0 and args.movement_speed is None and args.duration_ms is None
                      and args.diagnostic_frame_ms is None, 'Timing options require --time-ms.')
                check(not args.loop or args.step is not None, '--loop requires --step.')
            else:
                check(not args.loop, '--loop controls manual stepping only; timed playback uses profile rules.')
            def pair(value):
                try:
                    values = tuple(int(v) for v in value.split(','))
                except ValueError as exc:
                    raise ForgeError(ErrorCode.INVALID_ARGUMENT, 'Expected two comma-separated integers.') from exc
                check(len(values) == 2, 'Expected two comma-separated integers.')
                return values
            inspector = AnimationInspector(read_bytes(args.act), read_bytes(args.spr), category=args.category,
                head_act_bytes=read_bytes(args.head_act) if args.head_act else None,
                head_spr_bytes=read_bytes(args.head_spr) if args.head_spr else None)
            selection = inspector.timeline.select(action=args.action, slot=args.slot if args.action else (args.slot if args.slot is not None else 0),
                view=args.view, direction=args.direction, camera_direction=args.camera_direction, frame=args.frame)
            if args.step is not None:
                selection = inspector.timeline.step(selection, args.step, loop=args.loop)
            if args.time_ms is not None:
                selection = inspector.timeline.seek(selection, args.time_ms, speed=args.speed,
                    movement_speed=args.movement_speed, duration_ms=args.duration_ms,
                    diagnostic_frame_ms=args.diagnostic_frame_ms)
            result = inspector.inspect(selection, canvas_size=pair(args.canvas_size), origin=pair(args.origin), auto_fit=args.auto_fit)
            artifacts = []
            if args.json:
                artifacts.append((args.json, canonical_bytes(result['report'])))
            if args.output:
                artifacts.append((args.output, result['png_bytes']))
            if artifacts:
                publish_resources(tuple(artifacts))
            if not args.json:
                sys.stdout.write(canonical_bytes(result['report']).decode('utf-8'))
            return 0
        if args.command == 'preview':
            from ro_sprite_forge.formats.act import read_act
            from ro_sprite_forge.formats.spr import read_spr
            from ro_sprite_forge.formats.preview import composite_frame
            _input(args.act)
            _input(args.spr)
            if args.head_act:
                _input(args.head_act)
            if args.head_spr:
                _input(args.head_spr)
            if args.output:
                _output(args.output)
            if args.json:
                _output(args.json)

            act_bytes = read_bytes(args.act)
            spr_bytes = read_bytes(args.spr)
            source_hashes = {
                'act': hashlib.sha256(act_bytes).hexdigest(),
                'spr': hashlib.sha256(spr_bytes).hexdigest(),
            }
            act_data = read_act(act_bytes, path=args.act)
            spr_doc = read_spr(spr_bytes, path=args.spr)

            head_act_data = None
            head_spr_doc = None
            if args.head_act and args.head_spr:
                h_act_b = read_bytes(args.head_act)
                h_spr_b = read_bytes(args.head_spr)
                head_act_data = read_act(h_act_b, path=args.head_act)
                head_spr_doc = read_spr(h_spr_b, path=args.head_spr)
                source_hashes['head_act'] = hashlib.sha256(h_act_b).hexdigest()
                source_hashes['head_spr'] = hashlib.sha256(h_spr_b).hexdigest()

            origin = None
            if args.origin:
                parts = args.origin.split(',')
                if len(parts) != 2:
                    raise ForgeError(ErrorCode.INVALID_ARGUMENT, 'Origin must be X,Y.')
                origin = (int(parts[0]), int(parts[1]))

            canvas_size = None
            if args.canvas_size:
                parts = args.canvas_size.split(',')
                if len(parts) != 2:
                    raise ForgeError(ErrorCode.INVALID_ARGUMENT, 'Canvas size must be W,H.')
                canvas_size = (int(parts[0]), int(parts[1]))

            res = composite_frame(
                act_data,
                spr_doc,
                args.action,
                args.frame,
                head_act_data=head_act_data,
                head_spr_doc=head_spr_doc,
                head_frame_idx=args.head_frame,
                origin=origin,
                canvas_size=canvas_size,
                auto_fit=args.auto_fit,
                source_hashes=source_hashes,
            )

            if args.output:
                _publish_png(args.output, res['png_bytes'])
            if args.json:
                publish(args.json, res['report'])
            if args.stdout_json or (not args.output and not args.json):
                sys.stdout.write(canonical_bytes(res['report']).decode('utf-8'))
            return 0
        if args.command in ('coverage', 'missing'):
            from ro_sprite_forge.core.coverage import evaluate_coverage, format_work_order
            _input(args.requirements)
            if getattr(args, 'ledger', None):
                _input(args.ledger)
            if getattr(args, 'target', None):
                _input(args.target)
            if getattr(args, 'output', None):
                _output(args.output)
            if getattr(args, 'work_order_output', None):
                _output(args.work_order_output)
            data = {}
            for declaration in args.source:
                if '=' not in declaration:
                    raise ForgeError(ErrorCode.INVALID_ARGUMENT, 'Source must be ID=PATH.')
                sid, path = declaration.split('=', 1)
                if sid in data or sid in args.missing_source:
                    raise ForgeError(ErrorCode.INVALID_ARGUMENT, 'Duplicate source observation.')
                _input(path)
                data[sid] = read_bytes(path)
            for sid in args.missing_source:
                if sid in data:
                    raise ForgeError(ErrorCode.INVALID_ARGUMENT, 'Duplicate source observation.')
                data[sid] = None
            resolved_requirements = read_json(args.requirements)
            ledger_data = read_json(args.ledger) if getattr(args, 'ledger', None) else None
            target_data = read_json(args.target) if getattr(args, 'target', None) else None
            report = evaluate_coverage(resolved_requirements, ledger_data, source_bytes=data, target=target_data)

            filter_cat = args.filter if args.filter not in ('all', 'unresolved') else None
            filter_st = args.filter if args.filter in ('all', 'unresolved') else 'unresolved'
            work_order_text = format_work_order(report, filter_category=filter_cat, filter_status=filter_st)

            if args.command == 'coverage':
                if args.output:
                    publish(args.output, report)
                if args.work_order_output:
                    _publish_text(args.work_order_output, work_order_text)
                if args.work_order or (not args.output and not args.work_order_output):
                    sys.stdout.write(work_order_text)
            else:  # missing
                fmt = getattr(args, 'format', 'text')
                if args.output:
                    if fmt == 'json':
                        publish(args.output, report)
                    else:
                        _publish_text(args.output, work_order_text)
                else:
                    if fmt == 'json':
                        sys.stdout.write(canonical_bytes(report).decode('utf-8'))
                    else:
                        sys.stdout.write(work_order_text)
            return 0
        if args.command in ('ledger', 'ledger-impact'):
            from ro_sprite_forge.core.ledger import load_ledger, resolve_ledger, compare_ledgers
            _output(args.output)
            if args.command == 'ledger':
                for path in (args.requirements, args.ledger):
                    _input(path)
                data = {}
                for declaration in args.source:
                    if '=' not in declaration:
                        raise ForgeError(ErrorCode.INVALID_ARGUMENT, 'Source must be ID=PATH.')
                    sid, path = declaration.split('=', 1)
                    if sid in data or sid in args.missing_source:
                        raise ForgeError(ErrorCode.INVALID_ARGUMENT, 'Duplicate source observation.')
                    _input(path)
                    data[sid] = read_bytes(path)
                for sid in args.missing_source:
                    if sid in data:
                        raise ForgeError(ErrorCode.INVALID_ARGUMENT, 'Duplicate source observation.')
                    data[sid] = None
                resolved_requirements = read_json(args.requirements)
                ledger = load_ledger(read_json(args.ledger), requirements=resolved_requirements)
                report = resolve_ledger(ledger, requirements=resolved_requirements, source_bytes=data)
                publish(args.output, report)
                if any(a['kind'] != 'UNASSIGNED' and (a['validation'] != 'VALID' or a['availability'] not in ('AVAILABLE', 'REUSED'))
                       for a in report['assignments']):
                    raise ForgeError(ErrorCode.INVALID_INPUT, 'SOURCE_VERIFICATION_INCOMPLETE: diagnostic report published; no approved resource produced.')
            else:
                for path in (args.before, args.after):
                    _input(path)
                if args.requirements:
                    _input(args.requirements)
                report = compare_ledgers(read_json(args.before), read_json(args.after),
                    current_requirements=read_json(args.requirements) if args.requirements else None)
                publish(args.output, report)
            return 0
        if args.command == 'resolve':
            from ro_sprite_forge.core.contracts import load_actor, load_runtime_profile, load_target
            from ro_sprite_forge.core.topology import resolve_topology, topology_work_order
            for path in (args.actor, args.profile, args.target, *args.inventory):
                _input(path)
            _output(args.output)
            actor = load_actor(read_json(args.actor))
            profile = load_runtime_profile(read_json(args.profile))
            target = load_target(read_json(args.target), actor=actor, profile=profile)
            report = resolve_topology(target, actor=actor, profile=profile,
                                      inventories=tuple(read_json(p) for p in args.inventory))
            publish(args.output, report)
            if args.work_order:
                sys.stdout.write(topology_work_order(report))
            return 0
        request = _request(args)
        if request.operation == Operation.INSPECT:
            report = inventory(read_bytes(args.act), read_bytes(args.spr), actor=args.actor,
                               part=args.part, profile=get_profile(args.runtime_profile))
            publish(args.output, report)
        elif request.operation == Operation.PLAN:
            report = requirements(read_json(args.inventory), read_json(args.profile), read_json(args.target))
            publish(args.output, report)
        elif request.operation == Operation.ROUNDTRIP or (request.operation == Operation.VERIFY and not args.project):
            act, spr, report = roundtrip_pair(read_bytes(args.act), read_bytes(args.spr), mode=getattr(args, "mode", "preserve"))
            if request.operation == Operation.ROUNDTRIP:
                publish_resources(((args.output_act, act), (args.output_spr, spr)))
            sys.stdout.write(canonical_bytes(report).decode("utf-8"))
        else:
            execute(request)
    except ForgeError as exc:
        error = {"code": exc.code.value, "message": exc.message}
        if exc.path is not None:
            error["path"] = exc.path
        print(json.dumps({"error": error}, sort_keys=True), file=sys.stderr)
        if exc.code == ErrorCode.INVALID_ARGUMENT:
            return 2
        if exc.code == ErrorCode.NOT_IMPLEMENTED:
            return 4
        return 3
    return 0
